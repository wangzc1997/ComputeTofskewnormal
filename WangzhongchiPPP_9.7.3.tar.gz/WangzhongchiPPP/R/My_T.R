#' Compute the T-test value
#'
#' Take in the mu,sigmma,skewness
#' @param mu, sigmma, skewness
#'
#' @return T-test value
#'
#' @export
My_T<-function(u,sigma,alpha){
  n1 = 10;
  x0 <- rnorm(1,0,1)
  xi <- rnorm(n1,0,1)
  deta = alpha / sqrt(1 + alpha * alpha)
  z0i <- deta * abs(x0) + sqrt(1 - deta * deta) * xi
  z <- u + sqrt(sigma) * z0i
  z_ba <- mean(z)
  ss0 <- var(z0i)
  m2 <- (sum((z - z_ba) * (z - z_ba)))/(n1)
  m3 <- (sum((z - z_ba) * (z - z_ba) * (z - z_ba)))/n1
  deta_gu <- 1 - ss0
  t <- (z_ba - u - sqrt(sigma * deta_gu * (2/pi)))/(sqrt(sigma * deta_gu  * (1-(2/pi)-1/n1)+(1/n1)))
  return(t)
}
