#' Compute the T-test value
#'
#' Take in the mu,sigmma,skewness
#'
#' @docType package
#'
#' @author Wang Zhongchi \email{wangzhongchi@hdu.edu.cn}
#'
#' @name WangzhongchiCt
NULL
